Tweetie Select Bubbles
by kremalicious.com

Close Tweetie and put the two png files into Tweetie (Show Package Contents) > Contents > Resources overwriting the existing files. Start Tweetie and you should have the new select bubbles.

Free for your personal use. Original bubble graphic belongs to atebits.com so go and buy tweetie so they can afford another design session for a new selection bubble :-)
http://www.atebits.com/tweetie-mac/


Matthias Kretschmann
http://kremalicious.com